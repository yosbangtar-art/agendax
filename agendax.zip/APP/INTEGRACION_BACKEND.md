# Integración app ↔ backend

La app Flutter usa el backend FastAPI **tal como está** (`BACKEND/`, puerto 8001).
Este paquete contiene solo la parte de la app: no incluye ni modifica nada de `BACKEND/`.

La administración (servicios, barberos, cuentas, reportes, reseñas, citas) es
**solo web**: la app ya no tiene panel ni login de administrador.

## Cómo correrlo

```bash
# Backend
cd BACKEND
python run_server.py            # http://127.0.0.1:8001  (docs en /docs)

# App con el backend real
flutter pub get
flutter run -d chrome

# App sin servidor (datos de prueba en memoria)
flutter run --dart-define=USE_MOCK=true
```

- La dirección del servidor está en `lib/services/api_config.dart`
  (o con `--dart-define=API_URL=http://...`).
- Emulador Android: `http://10.0.2.2:8001`.
- Celular real: usar la IP del PC y arrancar uvicorn con `host="0.0.0.0"`
  (`run_server.py` hoy solo escucha en 127.0.0.1).

## Dónde está la conexión

| Archivo | Qué es |
|---|---|
| `lib/services/api_config.dart` | Dirección del servidor. |
| `lib/services/http_agenda_repository.dart` | Habla con la API: JSON, errores, mapeo de campos y estados. |
| `lib/services/agenda_repository.dart` | Contrato que usan las pantallas. |
| `lib/services/mock_agenda_repository.dart` | Datos de prueba (offline y pruebas). |

Endpoints que usa la app:

| Acción | Endpoint |
|---|---|
| Login / registro | `POST /usuarios/login`, `POST /usuarios/registro` (siempre `rol: "cliente"`) |
| Servicios / barberos | `GET /servicios/`, `GET /barberos/` |
| Horarios libres | `GET /barberos/{id}/disponibilidad?fecha=YYYY-MM-DD` |
| Mis citas / agenda del barbero | `GET /citas/?cliente_id=` · `GET /citas/?barbero_id=` |
| Reservar | `POST /citas/` |
| Cancelar | `PUT /citas/{id}/cancelar` |
| Confirmar / completar / no asistió | `PUT /citas/{id}/estado?nuevo_estado=` |
| Reprogramar | `PUT /citas/{id}/reprogramar?nueva_fecha_hora=` |
| Calificar / ver mis reseñas | `POST /resenas/`, `GET /resenas/` |

**Al unir con el repo de tu compañero:** esta carpeta `APP` reemplaza a la suya.
- `login_screen.dart` y `register_screen.dart` hacen lo mismo que los de él (mismos
  endpoints y mensajes), pero el login ahora **guarda el usuario de la sesión**;
  antes lo descartaba y la app no sabía de quién eran las citas.
- Su `api_service.dart` ya no se usa (la app no depende de él). Puede borrarse o
  conservarse sin afectar nada. Sus métodos ocultan los errores del servidor, por eso
  la app usa `http_agenda_repository.dart`.

## Lo que la app resuelve por su cuenta (porque el backend aún no lo hace)

- **Duración del servicio (RF-004):** `/disponibilidad` solo quita la hora de
  inicio exacta. La app además descarta horarios que se traslapan con citas
  vigentes según su duración, los que terminan después de las 18:00 y las horas pasadas.
- **Límite para reprogramar (RF-006):** 2 horas (`kRescheduleLimit`, valor
  provisional: el SRS no lo fija).
- **Reseñas:** valida cita completada, una por cita y 1–5 estrellas antes de enviar.
- **Filtro por día** de las citas y los nombres de servicio/barbero/precio (se
  cruzan con `/servicios/` y `/barberos/`).

Esto mejora la experiencia pero **no sustituye** la validación del servidor
(otro cliente podría reservar al mismo tiempo).

## Pendientes del backend

**Seguridad (alta)**
1. `POST /usuarios/registro` acepta el `rol` que envíe el cliente: cualquiera
   puede crear una cuenta `administrador`. El rol debe fijarse en el servidor.
2. La respuesta del registro devuelve el campo `password` (el hash). Debe
   excluirse del `response_model`.
3. No hay token ni sesión: todos los endpoints son públicos (cualquiera puede
   ver o cancelar citas de otros, crear servicios/barberos o ver
   `/admin/reportes/ingresos`). Falta autenticación por rol y expiración por
   inactividad (RNF-003).
4. Producción necesita HTTPS; la app hoy habilita HTTP en claro solo para desarrollo
   (`usesCleartextTraffic` en AndroidManifest).

**Funcionalidad que bloquea la app**
5. **Usuario ↔ barbero:** la tabla `barberos` no se relaciona con `usuarios`.
   La app vincula por **nombre exacto** (ignora mayúsculas y espacios dobles). Falta
   `usuario_id` en `barberos` (o que el login devuelva `barbero_id`).
6. **Cambiar contraseña:** no existe endpoint. El barbero recibe una contraseña
   temporal del admin y no puede cambiarla. Propuesta: `PUT /usuarios/{id}/password`
   con contraseña actual y nueva.
7. **Nombre del cliente:** no hay `GET /usuarios/...`, así que el barbero ve
   «Cliente #12». Propuesta: incluir `cliente_nombre` en la respuesta de citas.

**Reglas de negocio**
8. Doble reserva (RNF-006): solo compara `fecha_hora` idéntica; no considera
   duración ni traslapes. Debe validarse en el servidor.
9. Disponibilidad: horario fijo 09:00–18:00 igual para todos; no usa la duración
   del servicio ni el horario por barbero (RF-010), ni excluye horas pasadas.
10. Reprogramar: no aplica el límite de tiempo (RF-006) y no permite cambiar de barbero.
11. Estados: `PUT /citas/{id}/estado` no valida transiciones ni quién lo pide.
12. Reseñas: no valida cita completada, duplicados ni rango 1–5.
13. Precio histórico: la cita no guarda el precio; si el admin cambia el precio de un
    servicio, cambian también las citas viejas. Eliminar un servicio deja citas huérfanas.

**Para la parte web (admin)**
14. Solo existen `GET/POST` de servicios y barberos: faltan `PUT` y `DELETE`
    (RF-010, RF-011). Falta un campo `activo` para ocultar sin borrar.
15. Reportes (RF-014): solo hay ingresos totales. Faltan ocupación por barbero y
    rangos diario/semanal/mensual.
16. Recordatorios y notificaciones (RF-008): no implementados.

**Repositorio**
17. `requirements.txt` no incluye `sqlalchemy` ni `bcrypt` (el código los importa);
    una instalación limpia falla. Además está en UTF-16.
18. Se subieron `venv/`, `__pycache__/` y `barberia.db` (79 MB); conviene un `.gitignore`.
